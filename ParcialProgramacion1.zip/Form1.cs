﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParcialProgramacion
{
    public partial class Form1 : Form
    {
        private const string CadenaConexion =
           @"Server=localhost;Database=ParcialProgramacion1;Trusted_Connection=True;";
        public Form1()
        {                    
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

    }

        private void Guardar_Click(object sender, EventArgs e)
        {
            try
            {
                string conexion = @"Server=localhost;Database=ParcialProgramacion1;Trusted_Connection=True;";
                using (SqlConnection con = new SqlConnection(conexion))
                {
                    con.Open();

                    string query = "INSERT INTO NombreDeTuTabla (Nombre, Apellido, Edad) VALUES (@Nombre, @Apellido, @Edad)";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Producto", Producto.Text);
                        cmd.Parameters.AddWithValue("@Categoria", Categoria.Text);
                        cmd.Parameters.AddWithValue("@Precio", Precio.Text);
                        cmd.Parameters.AddWithValue("@Exitencia", Convert.ToInt32(Existencia.Text));

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Guardado correctamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

 
                Limpiar_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Limpiar_Click(object sender, EventArgs e)
        {
            Producto.Clear();
            Categoria.Clear();
            Precio.Clear();
            Existencia.Clear();
        }

        private void Eliminar_Click(object sender, EventArgs e)
        {

        }
    }
}
