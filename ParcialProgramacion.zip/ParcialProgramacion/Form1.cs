﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParcialProgramacion
{
    public partial class Form1 : Form
    {
        string cadena = @"Server=(localdb)\MSSQLLocalDB;Database=ParcialProgramacion1;Integrated Security=True;";
        int idSeleccionado = 0;

        public Form1()
        {
            InitializeComponent();
            Load += Form1_Load;
            Guardar.Click += Guardar_Click;
            Consultar.Click += Consultar_Click;
            Actualizar.Click += Actualizar_Click;
            Eliminar.Click += Eliminar_Click;
            Limpiar.Click += Limpiar_Click;
            dataGridView1.CellClick += dataGridView1_CellClick;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            MostrarProductos();
        }

     
        private void MostrarProductos()
        {
            SqlConnection cn = new SqlConnection(cadena);
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Productos", cn);
            DataTable tabla = new DataTable();
            da.Fill(tabla);
            dataGridView1.DataSource = tabla;
        }

 
        private bool DatosCorrectos()
        {
            if (Producto.Text == "" || Categoria.Text == "")
            {
                MessageBox.Show("El nombre y la categoría son obligatorios.");
                return false;
            }

            decimal precio;
            if (!decimal.TryParse(Precio.Text, out precio) || precio <= 0)
            {
                MessageBox.Show("El precio debe ser un número mayor que cero.");
                return false;
            }

            int existencia;
            if (!int.TryParse(Existencia.Text, out existencia) || existencia < 0)
            {
                MessageBox.Show("Las existencias deben ser un número entero mayor o igual a cero.");
                return false;
            }

            return true;
        }

        private void Limpiar_Click(object sender, EventArgs e)
        {
            Producto.Clear();
            Categoria.Clear();
            Precio.Clear();
            Existencia.Clear();
            idSeleccionado = 0;
        }

        private void Consultar_Click(object sender, EventArgs e)
        {
            try
            {
                MostrarProductos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void Guardar_Click(object sender, EventArgs e)
        {
            if (!DatosCorrectos()) return;

            try
            {
                SqlConnection cn = new SqlConnection(cadena);
                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Productos (Nombre, Categoria, Precio, Existencias) VALUES (@nombre, @categoria, @precio, @existencias)", cn);

                cmd.Parameters.AddWithValue("@nombre", Producto.Text);
                cmd.Parameters.AddWithValue("@categoria", Categoria.Text);
                cmd.Parameters.AddWithValue("@precio", decimal.Parse(Precio.Text));
                cmd.Parameters.AddWithValue("@existencias", int.Parse(Existencia.Text));

                cn.Open();
                cmd.ExecuteNonQuery();
                cn.Close();

                MessageBox.Show("Producto guardado correctamente.");
                Limpiar_Click(null, null);
                MostrarProductos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar: " + ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow fila = dataGridView1.Rows[e.RowIndex];
            idSeleccionado = int.Parse(fila.Cells["IdProducto"].Value.ToString());
            Producto.Text = fila.Cells["Nombre"].Value.ToString();
            Categoria.Text = fila.Cells["Categoria"].Value.ToString();
            Precio.Text = fila.Cells["Precio"].Value.ToString();
            Existencia.Text = fila.Cells["Existencias"].Value.ToString();
        }

        private void Actualizar_Click(object sender, EventArgs e)
        {
            if (idSeleccionado == 0)
            {
                MessageBox.Show("Seleccione un producto de la tabla.");
                return;
            }
            if (!DatosCorrectos()) return;

            try
            {
                SqlConnection cn = new SqlConnection(cadena);
                SqlCommand cmd = new SqlCommand(
                    "UPDATE Productos SET Nombre=@nombre, Categoria=@categoria, Precio=@precio, Existencias=@existencias WHERE IdProducto=@id", cn);

                cmd.Parameters.AddWithValue("@nombre", Producto.Text);
                cmd.Parameters.AddWithValue("@categoria", Categoria.Text);
                cmd.Parameters.AddWithValue("@precio", decimal.Parse(Precio.Text));
                cmd.Parameters.AddWithValue("@existencias", int.Parse(Existencia.Text));
                cmd.Parameters.AddWithValue("@id", idSeleccionado);

                cn.Open();
                cmd.ExecuteNonQuery();
                cn.Close();

                MessageBox.Show("Producto actualizado correctamente.");
                Limpiar_Click(null, null);
                MostrarProductos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar: " + ex.Message);
            }
        }

        private void Eliminar_Click(object sender, EventArgs e)
        {
            if (idSeleccionado == 0)
            {
                MessageBox.Show("Seleccione un producto de la tabla.");
                return;
            }

            DialogResult respuesta = MessageBox.Show("¿Desea eliminar el producto?", "Confirmar", MessageBoxButtons.YesNo);
            if (respuesta == DialogResult.No) return;

            try
            {
                SqlConnection cn = new SqlConnection(cadena);
                SqlCommand cmd = new SqlCommand("DELETE FROM Productos WHERE IdProducto=@id", cn);
                cmd.Parameters.AddWithValue("@id", idSeleccionado);

                cn.Open();
                cmd.ExecuteNonQuery();
                cn.Close();

                MessageBox.Show("Producto eliminado correctamente.");
                Limpiar_Click(null, null);
                MostrarProductos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar: " + ex.Message);
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}